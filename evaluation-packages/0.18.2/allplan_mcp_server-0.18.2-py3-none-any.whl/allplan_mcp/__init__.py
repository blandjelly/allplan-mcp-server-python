"""FastMCP bridge for the Allplan Python host."""

__all__ = ["__version__"]

__version__ = "0.18.2"
